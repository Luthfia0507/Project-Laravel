


<?php $__env->startSection('title', 'Edit Supplier | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Edit Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Edit Supplier ♡</h2>
        <p>Perbarui informasi pemasok produk Lp_Beauty.</p>
    </div>

    <?php if($errors->any()): ?>
        <div class="panel" style="color:#a12650; background:#fff0f5;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <form action="<?php echo e(route('suppliers.update', $supplier->id)); ?>"
              method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <label for="name">Nama Supplier *</label>
            <input type="text" id="name" name="name"
                value="<?php echo e(old('name', $supplier->name)); ?>"
                maxlength="255" required
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;">

            <label for="contact_person">Nama Kontak</label>
            <input type="text" id="contact_person" name="contact_person"
                value="<?php echo e(old('contact_person', $supplier->contact_person)); ?>"
                maxlength="255"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;">

            <label for="phone">Nomor Telepon</label>
            <input type="text" id="phone" name="phone"
                value="<?php echo e(old('phone', $supplier->phone)); ?>"
                maxlength="30"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;">

            <label for="email">Email</label>
            <input type="email" id="email" name="email"
                value="<?php echo e(old('email', $supplier->email)); ?>"
                maxlength="255"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;">

            <label for="address">Alamat</label>
            <textarea id="address" name="address" rows="3"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"><?php echo e(old('address', $supplier->address)); ?></textarea>

            <button type="submit" class="btn">Simpan Perubahan</button>

            <a href="<?php echo e(route('suppliers.index')); ?>"
               class="btn"
               style="margin-left:8px; text-decoration:none;">
                Batal
            </a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/suppliers/edit.blade.php ENDPATH**/ ?>