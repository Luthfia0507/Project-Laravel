


<?php $__env->startSection('title', 'Catat Pembelian | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Catat Pembelian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Catat Pembelian Baru ♡</h2>
        <p>Stok produk akan bertambah otomatis setelah transaksi berhasil disimpan.</p>
    </div>

    <?php if($errors->any()): ?>
        <div class="panel" style="color:#b42318;">
            <strong>Periksa kembali data berikut:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <?php if($suppliers->isEmpty()): ?>
            <p>Belum ada supplier. Tambahkan supplier terlebih dahulu melalui menu Supplier.</p>
        <?php elseif($products->isEmpty()): ?>
            <p>Belum ada produk. Tambahkan produk terlebih dahulu melalui menu Produk.</p>
        <?php else: ?>
            <form action="<?php echo e(route('purchases.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <label for="supplier_id">Supplier *</label>
                <select id="supplier_id" name="supplier_id" required
                    style="width:100%;padding:11px;margin:8px 0 16px;border:1px solid #e6cbd4;border-radius:8px;">
                    <option value="">-- Pilih Supplier --</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplier_id') == $supplier->id): echo 'selected'; endif; ?>>
                            <?php echo e($supplier->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label for="purchase_date">Tanggal Pembelian *</label>
                <input type="date" id="purchase_date" name="purchase_date"
                    value="<?php echo e(old('purchase_date', now()->format('Y-m-d'))); ?>" required
                    style="width:100%;padding:11px;margin:8px 0 16px;border:1px solid #e6cbd4;border-radius:8px;">

                <label for="notes">Catatan</label>
                <textarea id="notes" name="notes" rows="3"
                    style="width:100%;padding:11px;margin:8px 0 16px;border:1px solid #e6cbd4;border-radius:8px;"><?php echo e(old('notes')); ?></textarea>

                <h3>Produk yang Dibeli</h3>

                <div id="purchase-items">
                    <div class="purchase-item" style="border:1px solid #f0dce3;border-radius:10px;padding:14px;margin:12px 0;">
                        <label>Produk *</label>
                        <select name="items[0][product_id]" required
                            style="width:100%;padding:11px;margin:8px 0 12px;border:1px solid #e6cbd4;border-radius:8px;">
                            <option value="">-- Pilih Produk --</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>">
                                    <?php echo e($product->name); ?> (stok saat ini: <?php echo e($product->stock); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <label>Jumlah *</label>
                        <input type="number" name="items[0][quantity]" min="1" step="1" required
                            style="width:100%;padding:11px;margin:8px 0 12px;border:1px solid #e6cbd4;border-radius:8px;">

                        <label>Harga Beli per Unit (Rp) *</label>
                        <input type="number" name="items[0][unit_price]" min="0.01" step="0.01" required
                            style="width:100%;padding:11px;margin:8px 0 12px;border:1px solid #e6cbd4;border-radius:8px;">
                    </div>
                </div>

                <button type="button" id="add-item"
                    style="padding:10px 14px;border:1px solid #d98eaa;border-radius:8px;background:#fff0f5;color:#87445e;cursor:pointer;">
                    + Tambah Produk
                </button>

                <div style="margin-top:20px;">
                    <button type="submit" class="btn">Simpan Pembelian</button>
                    <a href="<?php echo e(route('purchases.index')); ?>"
                        style="margin-left:12px;color:#87445e;">Kembali</a>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById('add-item')?.addEventListener('click', function () {
            const container = document.getElementById('purchase-items');
            const index = container.querySelectorAll('.purchase-item').length;
            const template = container.querySelector('.purchase-item');
            const clone = template.cloneNode(true);

            clone.querySelectorAll('select, input').forEach(function (field) {
                field.name = field.name.replace(/items\[\d+\]/, 'items[' + index + ']');
                field.value = '';
            });

            container.appendChild(clone);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/purchases/create.blade.php ENDPATH**/ ?>