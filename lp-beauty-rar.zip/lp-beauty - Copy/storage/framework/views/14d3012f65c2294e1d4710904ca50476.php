

<?php $__env->startSection('title', 'Tambah Produk | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h2 style="color: #8f526b; margin-bottom: 8px;">
        Tambah Produk Baru 💗
    </h2>

    <p style="color: #927985; margin-top: 0;">
        Lengkapi informasi produk makeup dan skincare.
    </p>
</div>


<?php if($errors->any()): ?>
    <div class="alert-error">
        <strong>Ups! Periksa kembali data berikut:</strong>

        <ul style="margin-bottom: 0;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<div class="panel" style="max-width: 800px;">

    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div style="margin-bottom: 20px;">
            <label for="name" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Nama Produk <span style="color: #c96e8c;">*</span>
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?php echo e(old('name')); ?>"
                placeholder="Contoh: Moisturizer Hydrating"
                required
                maxlength="255"
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc;"
            >
        </div>

        
        <div style="margin-bottom: 20px;">
            <label for="sku" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Kode SKU
            </label>

            <input
                type="text"
                id="sku"
                name="sku"
                value=""
                placeholder="Pilih kategori terlebih dahulu"
                readonly
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fff0f5; color: #8f526b; font-weight: 600;"
            >

            <small id="sku-message" style="display: block; margin-top: 6px; color: #927985;">
                SKU akan dibuat otomatis sesuai kategori yang dipilih.
            </small>
        </div>

        
        <div style="margin-bottom: 20px;">
            <label for="brand" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Brand / Merek
            </label>

            <input
                type="text"
                id="brand"
                name="brand"
                value="<?php echo e(old('brand')); ?>"
                placeholder="Contoh: Wardah, Skintific, Emina"
                maxlength="255"
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc;"
            >
        </div>

        
        <div style="margin-bottom: 20px;">
            <label for="category_id" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Kategori <span style="color: #c96e8c;">*</span>
            </label>

            <select
                id="category_id"
                name="category_id"
                required
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc;"
            >
                <option value="">Pilih kategori produk</option>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($category->id); ?>"
                        <?php if(old('category_id') == $category->id): echo 'selected'; endif; ?>
                    >
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div style="margin-bottom: 20px;">
            <label for="price" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Harga (Rp) <span style="color: #c96e8c;">*</span>
            </label>

            <input
                type="number"
                id="price"
                name="price"
                min="0.01"
                step="0.01"
                value="<?php echo e(old('price')); ?>"
                placeholder="Contoh: 35000"
                required
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc;"
            >

            <small style="display: block; margin-top: 6px; color: #927985;">
                Masukkan angka tanpa tanda titik atau Rp.
            </small>
        </div>

        
        <div style="margin-bottom: 20px;">
            <label for="stock" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Jumlah Stok <span style="color: #c96e8c;">*</span>
            </label>

            <input
                type="number"
                id="stock"
                name="stock"
                min="0"
                value="<?php echo e(old('stock', 0)); ?>"
                placeholder="Contoh: 20"
                required
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc;"
            >
        </div>

        
        <div style="margin-bottom: 25px;">
            <label for="description" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Deskripsi Produk
            </label>

            <textarea
                id="description"
                name="description"
                rows="4"
                placeholder="Tuliskan deskripsi produk..."
                style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #e8cbd7; border-radius: 10px; background: #fffafc; resize: vertical;"
            ><?php echo e(old('description')); ?></textarea>
        </div>

        
        <div style="display: flex; flex-wrap: wrap; gap: 12px;">
            <button type="submit" id="submit-button" class="btn">
                💗 Simpan Produk
            </button>

            <a
                href="<?php echo e(route('products.index')); ?>"
                class="btn btn-light"
                style="text-decoration: none; display: inline-flex; align-items: center;"
            >
                ← Kembali
            </a>
        </div>

    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const categorySelect = document.getElementById('category_id');
    const skuInput = document.getElementById('sku');
    const skuMessage = document.getElementById('sku-message');
    const submitButton = document.getElementById('submit-button');

    let requestNumber = 0;

    async function updateSku() {
        const categoryId = categorySelect.value;
        const currentRequest = ++requestNumber;

        skuInput.value = '';
        submitButton.disabled = true;

        if (!categoryId) {
            skuInput.placeholder = 'Pilih kategori terlebih dahulu';
            skuMessage.textContent = 'SKU akan dibuat otomatis sesuai kategori yang dipilih.';
            return;
        }

        skuInput.placeholder = 'Sedang membuat SKU...';
        skuMessage.textContent = 'Mohon tunggu sebentar...';

        try {
            const url = new URL(
                <?php echo json_encode(route('products.next-sku'), 15, 512) ?>,
                window.location.origin
            );

            url.searchParams.set('category_id', categoryId);

            const response = await fetch(url, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin'
            });

            const data = await response.json();

            if (currentRequest !== requestNumber) {
                return;
            }

            if (!response.ok) {
                throw new Error(
                    data.message || 'SKU tidak berhasil dibuat.'
                );
            }

            skuInput.value = data.sku;
            skuMessage.textContent = 'SKU dibuat otomatis berdasarkan kategori.';
            submitButton.disabled = false;

        } catch (error) {
            if (currentRequest !== requestNumber) {
                return;
            }

            skuInput.value = '';
            skuInput.placeholder = 'SKU belum tersedia';
            skuMessage.textContent = error.message
                || 'Gagal membuat SKU. Silakan pilih kategori kembali.';

            submitButton.disabled = true;
        }
    }

    categorySelect.addEventListener('change', updateSku);

    // Jika kategori sudah terpilih setelah validasi gagal,
    // buat ulang SKU untuk kategori tersebut.
    if (categorySelect.value) {
        updateSku();
    }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/products/create.blade.php ENDPATH**/ ?>