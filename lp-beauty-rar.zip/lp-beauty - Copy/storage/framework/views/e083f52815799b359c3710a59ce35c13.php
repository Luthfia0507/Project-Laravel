


<?php $__env->startSection('title', 'Detail Penjualan | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Detail Penjualan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Detail Penjualan ♡</h2>
        <p>Rincian produk terjual dan riwayat pengembalian barang.</p>
    </div>

    <?php if(session('success')): ?>
        <div class="panel" style="color:#28784b;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="panel" style="color:#b42345;">
            <strong>Proses belum berhasil:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <p>
            <strong>No. Invoice:</strong>
            <?php echo e($sale->invoice_number); ?>

        </p>

        <p>
            <strong>Tanggal:</strong>
            <?php echo e(\Carbon\Carbon::parse($sale->sale_date)->format('d-m-Y')); ?>

        </p>

        <p>
            <strong>Dicatat oleh:</strong>
            <?php echo e($sale->user->name ?? '-'); ?>

        </p>

        <p>
            <strong>Status:</strong>
            <?php echo e(ucfirst($sale->status)); ?>

        </p>

        <?php if($sale->notes): ?>
            <p>
                <strong>Catatan:</strong>
                <?php echo e($sale->notes); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="panel">
        <h3>Produk yang Terjual</h3>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Produk</th>
                        <th>Jumlah Beli</th>
                        <th>Sudah Diretur</th>
                        <th>Sisa Bisa Diretur</th>
                        <th>Harga Satuan</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $returnedQuantity = \App\Models\SaleReturnItem::where(
                                'sale_item_id',
                                $item->id
                            )->sum('quantity');

                            $remainingQuantity = max(
                                0,
                                $item->quantity - $returnedQuantity
                            );
                        ?>

                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            <td>
                                <?php echo e($item->product->name ?? 'Produk tidak tersedia'); ?>

                            </td>

                            <td><?php echo e($item->quantity); ?></td>

                            <td><?php echo e($returnedQuantity); ?></td>

                            <td><?php echo e($remainingQuantity); ?></td>

                            <td>
                                Rp<?php echo e(number_format((float) $item->unit_price, 0, ',', '.')); ?>

                            </td>

                            <td>
                                Rp<?php echo e(number_format((float) $item->subtotal, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">
                                Belum ada detail produk pada transaksi ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

                <tfoot>
                    <tr>
                        <th colspan="6">Total Penjualan</th>
                        <th>
                            Rp<?php echo e(number_format((float) $sale->total_amount, 0, ',', '.')); ?>

                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <?php
            $hasReturnableItems = $sale->items->contains(function ($item) {
                $returned = \App\Models\SaleReturnItem::where(
                    'sale_item_id',
                    $item->id
                )->sum('quantity');

                return $returned < $item->quantity;
            });
        ?>

        <?php if($hasReturnableItems): ?>
            <a href="<?php echo e(route('sales.returns.create', $sale->id)); ?>"
               style="display:inline-block;margin-top:18px;padding:10px 16px;background:#e9a9c1;color:#542d40;border-radius:8px;text-decoration:none;font-weight:600;">
                + Proses Retur
            </a>
        <?php else: ?>
            <p style="margin-top:18px;color:#87445e;">
                Semua jumlah produk pada invoice ini sudah diretur.
            </p>
        <?php endif; ?>

        <a href="<?php echo e(route('sales.index')); ?>"
           style="display:inline-block;margin-top:16px;margin-left:10px;color:#87445e;">
            ← Kembali ke Penjualan
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/sales/show.blade.php ENDPATH**/ ?>