


<?php $__env->startSection('title', 'Supplier | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Manajemen Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Daftar Supplier ♡</h2>
    </div>


    <?php if($errors->any()): ?>
        <div class="panel" style="color:#a12650; background:#fff0f5;">
            <strong>Periksa kembali data yang kamu masukkan:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div style="display:flex; justify-content:flex-end; margin-bottom:18px;">
        <button
            type="button"
            class="btn"
            id="toggleSupplierForm"
            onclick="toggleSupplierForm()"
        >
            + Tambah Supplier
        </button>
    </div>

    <div class="panel" id="supplierFormPanel"
         style="display:<?php echo e($errors->any() ? 'block' : 'none'); ?>;">
        <h3>Tambah Supplier ♡</h3>

        <form action="<?php echo e(route('suppliers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label for="name">Nama Supplier *</label>
            <input
                type="text"
                id="name"
                name="name"
                value="<?php echo e(old('name')); ?>"
                maxlength="255"
                required
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"
            >

            <label for="contact_person">Nama Kontak</label>
            <input
                type="text"
                id="contact_person"
                name="contact_person"
                value="<?php echo e(old('contact_person')); ?>"
                maxlength="255"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"
            >

            <label for="phone">Nomor Telepon</label>
            <input
                type="text"
                id="phone"
                name="phone"
                value="<?php echo e(old('phone')); ?>"
                maxlength="30"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"
            >

            <label for="email">Email</label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                maxlength="255"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"
            >

            <label for="address">Alamat</label>
            <textarea
                id="address"
                name="address"
                rows="3"
                style="width:100%; padding:11px; margin:8px 0 12px; border:1px solid #e6cbd4; border-radius:8px;"
            ><?php echo e(old('address')); ?></textarea>

            <button type="submit" class="btn">
                Simpan Supplier
            </button>

            <button
                type="button"
                class="btn"
                onclick="toggleSupplierForm()"
                style="margin-left:8px;"
            >
                Batal
            </button>
        </form>
    </div>

    <div class="panel">
        <h3>Data Supplier</h3>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Supplier</th>
                        <th>Nama Kontak</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($supplier->name); ?></td>
                            <td><?php echo e($supplier->contact_person ?: '-'); ?></td>
                            <td><?php echo e($supplier->phone ?: '-'); ?></td>
                            <td><?php echo e($supplier->email ?: '-'); ?></td>
                            <td><?php echo e($supplier->address ?: '-'); ?></td>

                            <td style="white-space:nowrap;">
                                <a href="<?php echo e(route('suppliers.edit', $supplier->id)); ?>"
                                class="btn"
                                style="text-decoration:none;">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('suppliers.destroy', $supplier->id)); ?>"
                                    method="POST"
                                    style="display:inline;"
                                    onsubmit="return confirm('Yakin ingin menghapus supplier ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn"
                                            style="background:#a94464;">
                                        Hapus
                                    </button>
                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">
                                Belum ada data supplier ♡
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function toggleSupplierForm() {
            const form = document.getElementById('supplierFormPanel');
            const button = document.getElementById('toggleSupplierForm');

            if (form.style.display === 'none') {
                form.style.display = 'block';
                button.textContent = '− Tutup Formulir';
                form.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            } else {
                form.style.display = 'none';
                button.textContent = '+ Tambah Supplier';
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('supplierFormPanel');
            const button = document.getElementById('toggleSupplierForm');

            if (form.style.display !== 'none') {
                button.textContent = '− Tutup Formulir';
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/suppliers/index.blade.php ENDPATH**/ ?>