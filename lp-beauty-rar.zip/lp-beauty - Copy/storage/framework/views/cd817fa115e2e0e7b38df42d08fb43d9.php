


<?php $__env->startSection('title', 'Proses Retur | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Proses Retur'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Pengembalian Barang ♡</h2>
        <p>Catat barang yang dikembalikan pelanggan dengan teliti.</p>
    </div>

    <?php if($errors->any()): ?>
        <div class="panel" style="color:#b42345;">
            <strong>Periksa kembali data berikut:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <h3>Informasi Invoice</h3>

        <p>
            <strong>No. Invoice:</strong>
            <?php echo e($sale->invoice_number); ?>

        </p>

        <p>
            <strong>Tanggal Penjualan:</strong>
            <?php echo e(\Carbon\Carbon::parse($sale->sale_date)->format('d-m-Y')); ?>

        </p>

        <p>
            <strong>Total Penjualan:</strong>
            Rp<?php echo e(number_format((float) $sale->total_amount, 0, ',', '.')); ?>

        </p>
    </div>

    <form action="<?php echo e(route('sales.returns.store', $sale->id)); ?>"
          method="POST">
        <?php echo csrf_field(); ?>

        <div class="panel">
            <h3>Informasi Retur</h3>

            <div style="margin-bottom:16px;">
                <label for="return_date"
                       style="display:block;margin-bottom:6px;font-weight:600;">
                    Tanggal Retur
                </label>

                <input type="date"
                       id="return_date"
                       name="return_date"
                       value="<?php echo e(old('return_date', date('Y-m-d'))); ?>"
                       required
                       style="width:100%;max-width:350px;padding:10px;border:1px solid #e4c8d3;border-radius:8px;">
            </div>

            <div style="margin-bottom:16px;">
                <label for="resolution"
                       style="display:block;margin-bottom:6px;font-weight:600;">
                    Jenis Penyelesaian
                </label>

                <select name="resolution"
                        id="resolution"
                        required
                        style="width:100%;max-width:400px;padding:10px;border:1px solid #e4c8d3;border-radius:8px;">
                    <option value="return_only"
                        <?php echo e(old('resolution', 'return_only') === 'return_only' ? 'selected' : ''); ?>>
                        Pengembalian Barang
                    </option>

                    <option value="refund"
                        <?php echo e(old('resolution') === 'refund' ? 'selected' : ''); ?>>
                        Pengembalian Uang (Refund)
                    </option>

                    <option value="exchange"
                        <?php echo e(old('resolution') === 'exchange' ? 'selected' : ''); ?>>
                        Penukaran Barang
                    </option>
                </select>

                <p style="font-size:13px;color:#806574;margin-top:6px;">
                    Pilih satu jenis penyelesaian untuk seluruh item dalam pengajuan ini.
                </p>
            </div>

            <div>
                <label for="reason"
                       style="display:block;margin-bottom:6px;font-weight:600;">
                    Alasan Retur
                </label>

                <textarea name="reason"
                          id="reason"
                          rows="3"
                          placeholder="Contoh: produk rusak saat diterima..."
                          style="width:100%;padding:10px;border:1px solid #e4c8d3;border-radius:8px;"><?php echo e(old('reason')); ?></textarea>
            </div>
        </div>

        <div class="panel">
            <h3>Produk yang Dikembalikan</h3>

            <p style="color:#806574;font-size:14px;">
                Centang produk yang dikembalikan, lalu isi jumlah dan kondisi barangnya.
                Produk yang tidak dicentang tidak akan diproses.
            </p>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Pilih</th>
                            <th>Nama Produk</th>
                            <th>Dibeli</th>
                            <th>Sudah Diretur</th>
                            <th>Sisa Retur</th>
                            <th>Jumlah Retur</th>
                            <th>Kondisi Barang</th>
                            <th>Produk Pengganti</th>
                            <th>Jumlah Pengganti</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $returned = (int) ($returnedQuantities[$item->id] ?? 0);
                                $remaining = max(0, $item->quantity - $returned);
                                $oldItems = old('items', []);
                                $oldLine = collect($oldItems)->firstWhere(
                                    'sale_item_id',
                                    $item->id
                                );
                            ?>

                            <?php if($remaining > 0): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox"
                                               name="items[<?php echo e($item->id); ?>][selected]"
                                               value="1"
                                               class="return-select"
                                               data-row="<?php echo e($item->id); ?>"
                                               <?php echo e($oldLine ? 'checked' : ''); ?>>
                                    </td>

                                    <td>
                                        <?php echo e($item->product->name ?? 'Produk tidak tersedia'); ?>

                                        <input type="hidden"
                                               name="items[<?php echo e($item->id); ?>][sale_item_id]"
                                               value="<?php echo e($item->id); ?>">
                                    </td>

                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($returned); ?></td>
                                    <td><?php echo e($remaining); ?></td>

                                    <td>
                                        <input type="number"
                                               name="items[<?php echo e($item->id); ?>][quantity]"
                                               class="return-field return-quantity"
                                               data-row="<?php echo e($item->id); ?>"
                                               min="1"
                                               max="<?php echo e($remaining); ?>"
                                               value="<?php echo e($oldLine['quantity'] ?? 1); ?>"
                                               disabled
                                               style="width:75px;padding:7px;border:1px solid #e4c8d3;border-radius:6px;">
                                    </td>

                                    <td>
                                        <select name="items[<?php echo e($item->id); ?>][condition]"
                                                class="return-field"
                                                data-row="<?php echo e($item->id); ?>"
                                                disabled
                                                style="padding:7px;border:1px solid #e4c8d3;border-radius:6px;">
                                            <option value="resellable"
                                                <?php echo e(($oldLine['condition'] ?? '') === 'resellable' ? 'selected' : ''); ?>>
                                                Layak jual
                                            </option>

                                            <option value="damaged"
                                                <?php echo e(($oldLine['condition'] ?? '') === 'damaged' ? 'selected' : ''); ?>>
                                                Rusak
                                            </option>
                                        </select>
                                    </td>

                                    <td>
                                        <select name="items[<?php echo e($item->id); ?>][replacement_product_id]"
                                                class="return-field replacement-field"
                                                data-row="<?php echo e($item->id); ?>"
                                                disabled
                                                style="min-width:150px;padding:7px;border:1px solid #e4c8d3;border-radius:6px;">
                                            <option value="">Pilih produk</option>

                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>"
                                                    <?php echo e((string) ($oldLine['replacement_product_id'] ?? '') === (string) $product->id ? 'selected' : ''); ?>>
                                                    <?php echo e($product->name); ?> (Stok: <?php echo e($product->stock); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>

                                    <td>
                                        <input type="number"
                                               name="items[<?php echo e($item->id); ?>][replacement_quantity]"
                                               class="return-field replacement-field"
                                               data-row="<?php echo e($item->id); ?>"
                                               min="1"
                                               value="<?php echo e($oldLine['replacement_quantity'] ?? 1); ?>"
                                               disabled
                                               style="width:75px;padding:7px;border:1px solid #e4c8d3;border-radius:6px;">
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <p style="font-size:13px;color:#806574;margin-top:12px;">
                Barang layak jual menambah stok. Barang rusak tidak menambah stok jual.
                Jika penukaran dipilih, stok produk pengganti akan berkurang.
            </p>
        </div>

        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
            <button type="submit"
                    style="padding:11px 18px;background:#e9a9c1;color:#542d40;border:0;border-radius:8px;font-weight:600;cursor:pointer;">
                Simpan Retur
            </button>

            <a href="<?php echo e(route('sales.show', $sale->id)); ?>"
               style="display:inline-block;padding:11px 18px;color:#87445e;text-decoration:none;">
                Batal
            </a>
        </div>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const resolution = document.getElementById('resolution');
            const checkboxes = document.querySelectorAll('.return-select');

            function updateRows() {
                checkboxes.forEach(function (checkbox) {
                    const row = checkbox.dataset.row;
                    const fields = document.querySelectorAll(
                        '.return-field[data-row="' + row + '"]'
                    );

                    fields.forEach(function (field) {
                        field.disabled = !checkbox.checked;

                        if (field.classList.contains('replacement-field')) {
                            field.required =
                                checkbox.checked &&
                                resolution.value === 'exchange';
                        }
                    });
                });
            }

            function updateResolution() {
                const isExchange = resolution.value === 'exchange';

                document.querySelectorAll('.replacement-field').forEach(function (field) {
                    const row = field.dataset.row;
                    const checkbox = document.querySelector(
                        '.return-select[data-row="' + row + '"]'
                    );

                    field.disabled = !isExchange || !checkbox.checked;
                    field.required = isExchange && checkbox.checked;
                });
            }

            checkboxes.forEach(function (checkbox) {
                checkbox.addEventListener('change', updateRows);
            });

            resolution.addEventListener('change', function () {
                updateRows();
                updateResolution();
            });

            updateRows();
            updateResolution();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/sales/returns/create.blade.php ENDPATH**/ ?>