


<?php $__env->startSection('title', 'Transaksi Pembelian | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Transaksi Pembelian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Riwayat Pembelian ♡</h2>
    </div>

    <?php if(session('success')): ?>
        <div class="panel" style="color:#276749;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="panel" style="color:#b42318;">
            <strong>Transaksi belum berhasil:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="panel">
        <a href="<?php echo e(route('purchases.create')); ?>" class="btn">
            + Catat Pembelian
        </a>
    </div>

    <div class="panel">
        <h3>Daftar Transaksi</h3>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>No. Faktur</th>
                        <th>Tanggal</th>
                        <th>Supplier</th>
                        <th>Dicatat Oleh</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($purchase->invoice_number); ?></td>
                            <td><?php echo e($purchase->purchase_date->format('d-m-Y')); ?></td>
                            <td><?php echo e($purchase->supplier->name); ?></td>
                            <td><?php echo e($purchase->user->name); ?></td>
                            <td>Rp<?php echo e(number_format((float) $purchase->total_amount, 0, ',', '.')); ?></td>
                            <td><?php echo e(ucfirst($purchase->status)); ?></td>             
                        <td>
                            <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>"
                            style="color:#87445e;">
                                Lihat Detail
                            </a>
                        </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">Belum ada transaksi pembelian.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/purchases/index.blade.php ENDPATH**/ ?>