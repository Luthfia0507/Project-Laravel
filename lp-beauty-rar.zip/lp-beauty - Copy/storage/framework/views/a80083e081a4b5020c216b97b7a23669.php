

<?php $__env->startSection('title', 'Manajemen Stok | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Manajemen Stok'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h2 style="color:#8f526b;">Manajemen Stok ♡</h2>
    <p style="color:#927985;"></p>
</div>

<?php if(session('success')): ?>
    <div class="alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert-error">
        <ul style="margin:0;padding-left:20px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<div class="panel" style="margin-bottom:25px;">
    <h3 style="color:#8f526b;margin-top:0;">🌷 Catat Perubahan Stok</h3>

    <form action="<?php echo e(route('stock-movements.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:18px;">

            <div>
                <label for="product_id" style="display:block;margin-bottom:8px;font-weight:600;">
                    Pilih Produk
                </label>

                <select id="product_id" name="product_id" required
                    style="width:100%;box-sizing:border-box;padding:12px;border:1px solid #e8cbd7;border-radius:10px;background:#fffafc;">
                    <option value="">-- Pilih produk --</option>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"
                            <?php echo e((string)old('product_id') === (string)$product->id ? 'selected' : ''); ?>>
                            <?php echo e($product->name); ?> — Stok: <?php echo e($product->stock); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="type" style="display:block;margin-bottom:8px;font-weight:600;">
                    Jenis Transaksi
                </label>

                <select id="type" name="type" required
                    style="width:100%;box-sizing:border-box;padding:12px;border:1px solid #e8cbd7;border-radius:10px;background:#fffafc;">
                    <option value="">-- Pilih jenis --</option>
                    <option value="in" <?php echo e(old('type') === 'in' ? 'selected' : ''); ?>>Stok Masuk</option>
                    <option value="out" <?php echo e(old('type') === 'out' ? 'selected' : ''); ?>>Stok Keluar</option>
                </select>
            </div>

            <div>
                <label for="quantity" style="display:block;margin-bottom:8px;font-weight:600;">
                    Jumlah Unit
                </label>

                <input type="number" id="quantity" name="quantity"
                    value="<?php echo e(old('quantity')); ?>" min="1" step="1" required
                    style="width:100%;box-sizing:border-box;padding:12px;border:1px solid #e8cbd7;border-radius:10px;background:#fffafc;">
            </div>
        </div>

        <div style="margin-top:18px;">
            <label for="description" style="display:block;margin-bottom:8px;font-weight:600;">
                Keterangan (Opsional)
            </label>

            <textarea id="description" name="description" rows="3" maxlength="1000"
                placeholder="Contoh: Restok dari supplier atau barang keluar untuk pesanan."
                style="width:100%;box-sizing:border-box;padding:12px;border:1px solid #e8cbd7;border-radius:10px;background:#fffafc;"><?php echo e(old('description')); ?></textarea>
        </div>

        <div style="margin-top:20px;">
            <button type="submit" class="btn" <?php echo e($products->isEmpty() ? 'disabled' : ''); ?>>
                Simpan Perubahan Stok
            </button>
        </div>

        <?php if($products->isEmpty()): ?>
            <p class="muted">Belum ada produk. Tambahkan produk terlebih dahulu.</p>
        <?php endif; ?>
    </form>
</div>


<div class="panel">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:20px;">
        <h3 style="color:#8f526b;margin:0;">📋 Riwayat Pergerakan Stok</h3>
        <span style="background:#fbe7ef;color:#8f526b;padding:8px 14px;border-radius:20px;font-size:13px;font-weight:600;">
            <?php echo e($movements->count()); ?> Transaksi
        </span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Tanggal</th>
                    <th>Produk</th>
                    <th>Jenis</th>
                    <th>Jumlah</th>
                    <th>Stok Sebelum</th>
                    <th>Stok Sesudah</th>
                    <th>Keterangan</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td style="white-space:nowrap;">
                            <?php echo e($movement->created_at?->format('d/m/Y H:i') ?? '-'); ?>

                        </td>
                        <td><?php echo e($movement->product->name ?? 'Produk tidak tersedia'); ?></td>
                        <td>
                            <?php if($movement->type === 'in'): ?>
                                <span style="background:#e4f5e8;color:#287545;padding:5px 10px;border-radius:20px;font-size:12px;font-weight:600;">
                                    Stok Masuk
                                </span>
                            <?php else: ?>
                                <span style="background:#fce8ef;color:#a44c6b;padding:5px 10px;border-radius:20px;font-size:12px;font-weight:600;">
                                    Stok Keluar
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($movement->quantity); ?> unit</td>
                        <td><?php echo e($movement->stock_before); ?> unit</td>
                        <td><?php echo e($movement->stock_after); ?> unit</td>
                        <td><?php echo e($movement->description ?: '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" style="text-align:center;padding:30px;">
                            <p style="color:#8f526b;font-weight:600;">Belum ada riwayat stok ♡</p>
                            <p class="muted">Transaksi yang kamu simpan akan muncul di sini.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/stock-movements/index.blade.php ENDPATH**/ ?>