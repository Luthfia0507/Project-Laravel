


<?php $__env->startSection('title', 'Detail Pembelian | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Detail Pembelian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h2>Detail Pembelian ♡</h2>
        <p>Rincian produk yang dibeli dari supplier.</p>
    </div>

    <div class="panel">
        <p><strong>No. Faktur:</strong> <?php echo e($purchase->invoice_number); ?></p>
        <p><strong>Tanggal:</strong> <?php echo e($purchase->purchase_date->format('d-m-Y')); ?></p>
        <p><strong>Supplier:</strong> <?php echo e($purchase->supplier->name); ?></p>
        <p><strong>Dicatat oleh:</strong> <?php echo e($purchase->user->name); ?></p>
        <p><strong>Status:</strong> <?php echo e(ucfirst($purchase->status)); ?></p>

        <?php if($purchase->notes): ?>
            <p><strong>Catatan:</strong> <?php echo e($purchase->notes); ?></p>
        <?php endif; ?>
    </div>

    <div class="panel">
        <h3>Produk yang Dibeli</h3>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Produk</th>
                        <th>Jumlah</th>
                        <th>Harga Satuan</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->product->name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td>
                                Rp<?php echo e(number_format((float) $item->unit_price, 0, ',', '.')); ?>

                            </td>
                            <td>
                                Rp<?php echo e(number_format((float) $item->subtotal, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4">Total Pembelian</th>
                        <th>
                            Rp<?php echo e(number_format((float) $purchase->total_amount, 0, ',', '.')); ?>

                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <a href="<?php echo e(route('purchases.index')); ?>"
           style="display:inline-block;margin-top:16px;color:#87445e;">
            ← Kembali ke Pembelian
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/purchases/show.blade.php ENDPATH**/ ?>