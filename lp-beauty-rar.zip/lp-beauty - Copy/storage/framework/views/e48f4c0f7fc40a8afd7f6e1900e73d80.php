

<?php $__env->startSection('title', 'Semua Produk | Lp_Beauty'); ?>
<?php $__env->startSection('page-title', 'Semua Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h2>Daftar Produk ♡</h2>
</div>


<div class="panel">
    <form action="<?php echo e(route('products.index')); ?>" method="GET">
        <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:end;">

            <div style="flex:1; min-width:200px;">
                <label for="search" style="display:block; margin-bottom:8px; font-weight:600;">
                    Cari Produk
                </label>

                <input
                    type="text"
                    id="search"
                    name="search"
                    placeholder="Nama produk, brand, atau SKU..."
                    value="<?php echo e($search ?? ''); ?>"
                    style="width:100%; box-sizing:border-box; padding:12px; border:1px solid #e6cbd4; border-radius:8px;"
                >
            </div>

            <div style="flex:1; min-width:180px;">
                <label for="category" style="display:block; margin-bottom:8px; font-weight:600;">
                    Kategori
                </label>

                <select
                    id="category"
                    name="category"
                    style="width:100%; box-sizing:border-box; padding:12px; border:1px solid #e6cbd4; border-radius:8px;"
                >
                    <option value="">Semua Kategori</option>

                    <?php $__currentLoopData = \App\Models\Category::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($category->id); ?>"
                            <?php if((string) ($selectedCategory ?? '') === (string) $category->id): echo 'selected'; endif; ?>
                        >
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn">Cari</button>

            <a href="<?php echo e(route('products.index')); ?>" class="btn-light">
                Reset
            </a>
        </div>
    </form>
</div>


<?php if(auth()->user()->role === 'admin'): ?>
    <div style="display:flex; justify-content:flex-end; margin:20px 0;">
        <a href="<?php echo e(route('products.create')); ?>" class="btn">
            + Tambah Produk
        </a>
    </div>
<?php endif; ?>


<div class="panel">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>SKU</th>
                    <th>Nama Produk</th>
                    <th>Brand</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>

                        
                        <td style="white-space:nowrap;">
                            <span style="display:inline-block; background:#fff0f5; color:#a44c6b; padding:5px 9px; border-radius:6px; font-weight:600; font-size:13px;">
                                <?php echo e($product->sku ?: '-'); ?>

                            </span>
                        </td>

                        
                        <td>
                            <a
                                href="<?php echo e(route('products.show', $product->id)); ?>"
                                style="color:#a64d79; text-decoration:none; font-weight:600;"
                            >
                                <?php echo e($product->name); ?>

                            </a>
                        </td>

                        <td><?php echo e($product->brand ?: '-'); ?></td>

                        <td><?php echo e($product->category->name ?? '-'); ?></td>

                        <td style="white-space:nowrap; color:#b65779;">
                            <strong>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></strong>
                        </td>

                        <td>
                            <span style="display:inline-block; background:#fce8ef; color:#a44c6b; padding:5px 10px; border-radius:20px;">
                                <?php echo e($product->stock); ?>

                            </span>
                        </td>

                        
                        <td>
                            <?php if(auth()->user()->role === 'admin'): ?>
                                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                    <a
                                        href="<?php echo e(route('products.edit', $product->id)); ?>"
                                        style="display:inline-block; background:#f5d5e0; color:#8c3f5b; text-decoration:none; padding:8px 12px; border-radius:6px;"
                                    >
                                        Edit
                                    </a>

                                    <form
                                        action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                        method="POST"
                                        onsubmit="return confirm('Yakin ingin menghapus produk ini dari Lp_Beauty?')"
                                    >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            style="background:#c96e8c; color:white; border:none; padding:8px 12px; border-radius:6px; cursor:pointer;"
                                        >
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <span class="muted">Lihat saja</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" style="text-align:center; padding:35px 15px;">
                            <h3 style="color:#a84f70;">
                                <?php echo e(!empty($search) || !empty($selectedCategory) ? 'Produk Tidak Ditemukan ♡' : 'Belum Ada Produk ♡'); ?>

                            </h3>

                            <p class="muted">
                                <?php echo e(!empty($search) || !empty($selectedCategory)
                                    ? 'Coba ubah kata pencarian atau kategori.'
                                    : (auth()->user()->role === 'admin'
                                        ? 'Tambahkan produk makeup atau skincare pertamamu.'
                                        : 'Belum ada produk yang ditampilkan.')); ?>

                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lp-beauty\resources\views/products/index.blade.php ENDPATH**/ ?>